package com.support24by7.helpWorkflowService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelpWorkflowServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
