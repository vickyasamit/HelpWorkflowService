package com.support24by7.helpWorkflowService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelpWorkflowServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelpWorkflowServiceApplication.class, args);
	}

}
